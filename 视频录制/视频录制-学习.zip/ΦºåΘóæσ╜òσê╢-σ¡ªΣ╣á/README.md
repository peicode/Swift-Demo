# VideoRecord
视频录制和屏幕录制（学习中）
![image](https://github.com/PEIcode/VideoRecord/blob/master/Image/%E8%A7%86%E9%A2%91%E5%BD%95%E5%88%B6%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F.png)
![image](https://github.com/PEIcode/VideoRecord/blob/master/Image/Video.jpg)
![image](https://github.com/PEIcode/VideoRecord/blob/master/Image/%E7%9B%B4%E6%92%AD%E6%8A%80%E6%9C%AF%E7%82%B9.jpg)
